Movie Ticket Booking System (Java)

How to Run:
1. Install Java (JDK)
2. Open terminal in this folder
3. Compile:
   javac MovieSystem.java Movie.java Booking.java
4. Run:
   java MovieSystem

Features:
- Show available movies
- Book movie tickets
- Store booking history in bookings.txt
- View booking history
