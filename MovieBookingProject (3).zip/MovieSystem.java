import java.util.*;
import java.io.*;

public class MovieSystem {
    static ArrayList<Movie> movies = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {

        movies.add(new Movie(1, "Avengers", 50));
        movies.add(new Movie(2, "Inception", 40));
        movies.add(new Movie(3, "Interstellar", 30));

        while(true) {
            System.out.println("\n Movie Ticket Booking");
            System.out.println("1. Show Movies");
            System.out.println("2. Book Ticket");
            System.out.println("3. View Booking History");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();

            switch(choice) {
                case 1: showMovies(); break;
                case 2: bookTicket(); break;
                case 3: viewHistory(); break;
                case 4: System.exit(0);
            }
        }
    }

    static void showMovies() {
        System.out.println("\nAvailable Movies:");
        for(Movie m : movies) {
            System.out.println(m.id + ". " + m.name + " | Seats: " + m.availableSeats);
        }
    }

    static void bookTicket() throws Exception {
        System.out.print("Enter your name: ");
        sc.nextLine();
        String cname = sc.nextLine();

        showMovies();
        System.out.print("Select Movie ID: ");
        int mid = sc.nextInt();

        Movie selected = null;
        for(Movie m : movies) {
            if(m.id == mid) selected = m;
        }

        if(selected == null) {
            System.out.println("Invalid Movie!");
            return;
        }

        System.out.print("Enter seats to book: ");
        int seats = sc.nextInt();

        if(seats > selected.availableSeats) {
            System.out.println("Not enough seats!");
            return;
        }

        selected.availableSeats -= seats;

        FileWriter fw = new FileWriter("bookings.txt", true);
        fw.write(cname + "," + selected.name + "," + seats + "\n");
        fw.close();

        System.out.println("Booking Successful!");
    }

    static void viewHistory() throws Exception {
        File file = new File("bookings.txt");
        if(!file.exists()) {
            System.out.println("No bookings yet!");
            return;
        }

        Scanner fileSc = new Scanner(file);
        System.out.println("\nBooking History:");
        while(fileSc.hasNextLine()) {
            String line = fileSc.nextLine();
            String data[] = line.split(",");
            System.out.println("Name: " + data[0] + " | Movie: " + data[1] + " | Seats: " + data[2]);
        }
        fileSc.close();
    }
}
