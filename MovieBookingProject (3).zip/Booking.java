public class Booking {
    String customerName;
    String movieName;
    int seatsBooked;

    public Booking(String customerName, String movieName, int seatsBooked) {
        this.customerName = customerName;
        this.movieName = movieName;
        this.seatsBooked = seatsBooked;
    }
}
