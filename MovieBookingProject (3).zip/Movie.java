public class Movie {
    int id;
    String name;
    int availableSeats;

    public Movie(int id, String name, int availableSeats) {
        this.id = id;
        this.name = name;
        this.availableSeats = availableSeats;
    }
}
